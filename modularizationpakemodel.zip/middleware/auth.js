const jwt = require('jsonwebtoken');
const { errorResponse } = require('../utils/response');
const jwtConfig = require('../config/jwt');

const authenticateToken = (req, res, next) => {
  try {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
      return errorResponse(res, 'Token tidak ditemukan', {}, 401);
    }

    jwt.verify(token, jwtConfig.secretKey, (err, user) => {
      if (err) {
        return errorResponse(res, 'Token tidak valid', {}, 403);
      }
      req.user = user;
      next();
    });
  } catch (err) {
    console.error('Authentication error:', err);
    return errorResponse(res, 'Gagal melakukan autentikasi', { detail: err.message });
  }
};

module.exports = {
  authenticateToken,
};
