const { getConnection } = require('../config/database');

class Regency {
  static async getAll() {
    const db = getConnection();
    const [rows] = await db.execute('SELECT regency_id AS id, province_id, name FROM regencies_ref');
    return rows;
  }

  static async getById(id) {
    const db = getConnection();
    const [rows] = await db.execute('SELECT * FROM regencies_ref WHERE regency_id = ?', [id]);
    return rows[0];
  }

  static async getByProvinceId(provinceId) {
    const db = getConnection();
    const [rows] = await db.execute('SELECT * FROM regencies_ref WHERE province_id = ?', [provinceId]);
    return rows;
  }

  static async create(regencyId, provinceId, name) {
    const db = getConnection();
    const [result] = await db.execute('INSERT INTO regencies_ref (regency_id, province_id, name) VALUES (?, ?, ?)', [regencyId, provinceId, name]);
    return { regency_id: regencyId, province_id: provinceId, name };
  }

  static async update(regencyId, name) {
    const db = getConnection();
    const [result] = await db.execute('UPDATE regencies_ref SET name = ?, updated_at = NOW() WHERE regency_id = ?', [name, regencyId]);
    return result.affectedRows > 0;
  }

  static async delete(regencyId) {
    const db = getConnection();
    const [result] = await db.execute('DELETE FROM regencies_ref WHERE regency_id = ?', [regencyId]);
    return result.affectedRows > 0;
  }
}

module.exports = Regency;
