const { getConnection } = require('../config/database');

class Province {
  static async getAll() {
    const db = getConnection();
    const [rows] = await db.execute('SELECT province_id AS id, name FROM provinces_ref');
    return rows;
  }

  static async getById(id) {
    const db = getConnection();
    const [rows] = await db.execute('SELECT * FROM provinces_ref WHERE province_id = ?', [id]);
    return rows[0];
  }

  static async create(provinceId, name) {
    const db = getConnection();
    const [result] = await db.execute('INSERT INTO provinces_ref (province_id, name) VALUES (?, ?)', [provinceId, name]);
    return { province_id: provinceId, name };
  }

  static async update(provinceId, name) {
    const db = getConnection();
    const [result] = await db.execute('UPDATE provinces_ref SET name = ?, updated_at = NOW() WHERE province_id = ?', [name, provinceId]);
    return result.affectedRows > 0;
  }

  static async delete(provinceId) {
    const db = getConnection();
    const [result] = await db.execute('DELETE FROM provinces_ref WHERE province_id = ?', [provinceId]);
    return result.affectedRows > 0;
  }
}

module.exports = Province;
