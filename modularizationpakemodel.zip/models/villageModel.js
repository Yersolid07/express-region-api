const { getConnection } = require('../config/database');

class Village {
  static async getAll() {
    const db = getConnection();
    const [rows] = await db.execute('SELECT village_id AS id, district_id, name FROM villages_ref');
    return rows;
  }

  static async getById(id) {
    const db = getConnection();
    const [rows] = await db.execute('SELECT * FROM villages_ref WHERE village_id = ?', [id]);
    return rows[0];
  }

  static async getByDistrictId(districtId) {
    const db = getConnection();
    const [rows] = await db.execute('SELECT * FROM villages_ref WHERE district_id = ?', [districtId]);
    return rows;
  }

  static async create(villageId, districtId, name) {
    const db = getConnection();
    const [result] = await db.execute('INSERT INTO villages_ref (village_id, district_id, name) VALUES (?, ?, ?)', [villageId, districtId, name]);
    return { village_id: villageId, district_id: districtId, name };
  }

  static async update(villageId, name) {
    const db = getConnection();
    const [result] = await db.execute('UPDATE villages_ref SET name = ?, updated_at = NOW() WHERE village_id = ?', [name, villageId]);
    return result.affectedRows > 0;
  }

  static async delete(villageId) {
    const db = getConnection();
    const [result] = await db.execute('DELETE FROM villages_ref WHERE village_id = ?', [villageId]);
    return result.affectedRows > 0;
  }
}

module.exports = Village;
