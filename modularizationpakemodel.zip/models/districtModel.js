const { getConnection } = require('../config/database');

class District {
  static async getAll() {
    const db = getConnection();
    const [rows] = await db.execute('SELECT district_id AS id, regency_id, name FROM districts_ref');
    return rows;
  }

  static async getById(id) {
    const db = getConnection();
    const [rows] = await db.execute('SELECT * FROM districts_ref WHERE district_id = ?', [id]);
    return rows[0];
  }

  static async getByRegencyId(regencyId) {
    const db = getConnection();
    const [rows] = await db.execute('SELECT * FROM districts_ref WHERE regency_id = ?', [regencyId]);
    return rows;
  }

  static async create(districtId, regencyId, name) {
    const db = getConnection();
    const [result] = await db.execute('INSERT INTO districts_ref (district_id, regency_id, name) VALUES (?, ?, ?)', [districtId, regencyId, name]);
    return { district_id: districtId, regency_id: regencyId, name };
  }

  static async update(districtId, name) {
    const db = getConnection();
    const [result] = await db.execute('UPDATE districts_ref SET name = ?, updated_at = NOW() WHERE district_id = ?', [name, districtId]);
    return result.affectedRows > 0;
  }

  static async delete(districtId) {
    const db = getConnection();
    const [result] = await db.execute('DELETE FROM districts_ref WHERE district_id = ?', [districtId]);
    return result.affectedRows > 0;
  }
}

module.exports = District;
