const express = require('express');
const router = express.Router();
const { login, logout } = require('../controllers/authController');
const { authenticateToken } = require('../middleware/auth');

// Route untuk login
router.post('/login', login);

// Route untuk logout (membutuhkan autentikasi)
router.post('/logout', authenticateToken, logout);

module.exports = router;
