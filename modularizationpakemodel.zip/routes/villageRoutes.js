const express = require('express');
const router = express.Router();
const authenticateJWT = require('../middleware/auth');
const { getVillages, getVillageById, getVillagesByDistrictId, createVillage, updateVillage, deleteVillage } = require('../controllers/villageController');

router.route('/').get(authenticateJWT, getVillages).post(authenticateJWT, createVillage);

router.route('/:id').get(authenticateJWT, getVillageById).patch(authenticateJWT, updateVillage).delete(authenticateJWT, deleteVillage);

router.get('/district/:districtId', authenticateJWT, getVillagesByDistrictId);

module.exports = router;
