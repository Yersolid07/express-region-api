const express = require('express');
const router = express.Router();
const authenticateJWT = require('../middleware/auth');
const { getProvinces, getProvinceById, createProvince, updateProvince, deleteProvince } = require('../controllers/provinceController');

router.route('/').get(authenticateJWT, getProvinces).post(authenticateJWT, createProvince);

router.route('/:id').get(authenticateJWT, getProvinceById).patch(authenticateJWT, updateProvince).delete(authenticateJWT, deleteProvince);

module.exports = router;
