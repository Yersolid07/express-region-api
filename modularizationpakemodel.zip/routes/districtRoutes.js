const express = require('express');
const router = express.Router();
const authenticateJWT = require('../middleware/auth');
const { getDistricts, getDistrictById, getDistrictsByRegencyId, createDistrict, updateDistrict, deleteDistrict } = require('../controllers/districtController');

router.route('/').get(authenticateJWT, getDistricts).post(authenticateJWT, createDistrict);

router.route('/:id').get(authenticateJWT, getDistrictById).patch(authenticateJWT, updateDistrict).delete(authenticateJWT, deleteDistrict);

router.get('/regency/:regencyId', authenticateJWT, getDistrictsByRegencyId);

module.exports = router;
