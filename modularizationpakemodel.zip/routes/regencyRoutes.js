const express = require('express');
const router = express.Router();
const authenticateJWT = require('../middleware/auth');
const { getRegencies, getRegencyById, getRegenciesByProvinceId, createRegency, updateRegency, deleteRegency } = require('../controllers/regencyController');

// Get all regencies and create new regency
router.route('/').get(authenticateJWT, getRegencies).post(authenticateJWT, createRegency);

// Get, update and delete specific regency
router.route('/:id').get(authenticateJWT, getRegencyById).patch(authenticateJWT, updateRegency).delete(authenticateJWT, deleteRegency);

// Get regencies by province (harus di bawah route /:id)
router.get('/province/:provinceId', authenticateJWT, getRegenciesByProvinceId);

module.exports = router;
