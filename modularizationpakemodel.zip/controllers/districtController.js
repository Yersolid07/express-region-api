const District = require('../models/districtModel');
const { successResponse, errorResponse } = require('../utils/response');

const getDistricts = async (req, res) => {
  try {
    const districts = await District.getAll();
    return successResponse(res, 'Daftar kecamatan berhasil diambil', {
      items: districts,
      total: districts.length,
      page: parseInt(req.query.page) || 1,
      limit: parseInt(req.query.limit) || 10,
      totalPages: Math.ceil(districts.length / (parseInt(req.query.limit) || 10)),
    });
  } catch (err) {
    return errorResponse(res, 'Gagal mengambil daftar kecamatan', { detail: err.message });
  }
};

const getDistrictById = async (req, res) => {
  try {
    const district = await District.getById(req.params.id);
    if (!district) {
      return errorResponse(res, 'Kecamatan tidak ditemukan', {}, 404);
    }
    return successResponse(res, 'Kecamatan berhasil diambil', district);
  } catch (err) {
    return errorResponse(res, 'Gagal mengambil kecamatan', { detail: err.message });
  }
};

const getDistrictsByRegencyId = async (req, res) => {
  try {
    const districts = await District.getByRegencyId(req.params.regencyId);
    return successResponse(res, 'Daftar kecamatan berhasil diambil', districts);
  } catch (err) {
    return errorResponse(res, 'Gagal mengambil daftar kecamatan', { detail: err.message });
  }
};

const createDistrict = async (req, res) => {
  const { district_id, regency_id, name } = req.body;
  if (!district_id || !regency_id || !name) {
    return errorResponse(res, 'district_id, regency_id, dan name wajib diisi', {}, 400);
  }
  try {
    const district = await District.create(district_id, regency_id, name);
    return successResponse(res, 'Kecamatan berhasil ditambah', district, 201);
  } catch (err) {
    return errorResponse(res, 'Gagal menambah kecamatan', { detail: err.message });
  }
};

const updateDistrict = async (req, res) => {
  const { name } = req.body;
  if (!name) {
    return errorResponse(res, 'Nama kecamatan wajib diisi', {}, 400);
  }
  try {
    const updated = await District.update(req.params.id, name);
    if (!updated) {
      return errorResponse(res, 'Kecamatan tidak ditemukan', {}, 404);
    }
    return successResponse(res, 'Kecamatan berhasil diperbarui', { district_id: req.params.id, name });
  } catch (err) {
    return errorResponse(res, 'Gagal memperbarui kecamatan', { detail: err.message });
  }
};

const deleteDistrict = async (req, res) => {
  try {
    const deleted = await District.delete(req.params.id);
    if (!deleted) {
      return errorResponse(res, 'Kecamatan tidak ditemukan', {}, 404);
    }
    return successResponse(res, 'Kecamatan berhasil dihapus', {});
  } catch (err) {
    return errorResponse(res, 'Gagal menghapus kecamatan', { detail: err.message });
  }
};

module.exports = {
  getDistricts,
  getDistrictById,
  getDistrictsByRegencyId,
  createDistrict,
  updateDistrict,
  deleteDistrict,
};
