const Village = require('../models/villageModel');
const { successResponse, errorResponse } = require('../utils/response');

const getVillages = async (req, res) => {
  try {
    const villages = await Village.getAll();
    return successResponse(res, 'Daftar desa berhasil diambil', {
      items: villages,
      total: villages.length,
      page: parseInt(req.query.page) || 1,
      limit: parseInt(req.query.limit) || 10,
      totalPages: Math.ceil(villages.length / (parseInt(req.query.limit) || 10)),
    });
  } catch (err) {
    return errorResponse(res, 'Gagal mengambil daftar desa', { detail: err.message });
  }
};

const getVillageById = async (req, res) => {
  try {
    const village = await Village.getById(req.params.id);
    if (!village) {
      return errorResponse(res, 'Desa tidak ditemukan', {}, 404);
    }
    return successResponse(res, 'Desa berhasil diambil', village);
  } catch (err) {
    return errorResponse(res, 'Gagal mengambil desa', { detail: err.message });
  }
};

const getVillagesByDistrictId = async (req, res) => {
  try {
    const villages = await Village.getByDistrictId(req.params.districtId);
    return successResponse(res, 'Daftar desa berhasil diambil', villages);
  } catch (err) {
    return errorResponse(res, 'Gagal mengambil daftar desa', { detail: err.message });
  }
};

const createVillage = async (req, res) => {
  const { village_id, district_id, name } = req.body;
  if (!village_id || !district_id || !name) {
    return errorResponse(res, 'village_id, district_id, dan name wajib diisi', {}, 400);
  }
  try {
    const village = await Village.create(village_id, district_id, name);
    return successResponse(res, 'Desa berhasil ditambah', village, 201);
  } catch (err) {
    return errorResponse(res, 'Gagal menambah desa', { detail: err.message });
  }
};

const updateVillage = async (req, res) => {
  const { name } = req.body;
  if (!name) {
    return errorResponse(res, 'Nama desa wajib diisi', {}, 400);
  }
  try {
    const updated = await Village.update(req.params.id, name);
    if (!updated) {
      return errorResponse(res, 'Desa tidak ditemukan', {}, 404);
    }
    return successResponse(res, 'Desa berhasil diperbarui', { village_id: req.params.id, name });
  } catch (err) {
    return errorResponse(res, 'Gagal memperbarui desa', { detail: err.message });
  }
};

const deleteVillage = async (req, res) => {
  try {
    const deleted = await Village.delete(req.params.id);
    if (!deleted) {
      return errorResponse(res, 'Desa tidak ditemukan', {}, 404);
    }
    return successResponse(res, 'Desa berhasil dihapus', {});
  } catch (err) {
    return errorResponse(res, 'Gagal menghapus desa', { detail: err.message });
  }
};

module.exports = {
  getVillages,
  getVillageById,
  getVillagesByDistrictId,
  createVillage,
  updateVillage,
  deleteVillage,
};
