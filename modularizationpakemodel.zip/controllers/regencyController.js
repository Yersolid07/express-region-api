const Regency = require('../models/regencyModel');
const { successResponse, errorResponse } = require('../utils/response');

const getRegencies = async (req, res) => {
  try {
    const regencies = await Regency.getAll();
    return successResponse(res, 'Daftar kabupaten berhasil diambil', {
      items: regencies,
      total: regencies.length,
      page: parseInt(req.query.page) || 1,
      limit: parseInt(req.query.limit) || 10,
      totalPages: Math.ceil(regencies.length / (parseInt(req.query.limit) || 10)),
    });
  } catch (err) {
    return errorResponse(res, 'Gagal mengambil daftar kabupaten', { detail: err.message });
  }
};

const getRegencyById = async (req, res) => {
  try {
    const regency = await Regency.getById(req.params.id);
    if (!regency) {
      return errorResponse(res, 'Kabupaten tidak ditemukan', {}, 404);
    }
    return successResponse(res, 'Kabupaten berhasil diambil', regency);
  } catch (err) {
    return errorResponse(res, 'Gagal mengambil kabupaten', { detail: err.message });
  }
};

const getRegenciesByProvinceId = async (req, res) => {
  try {
    const regencies = await Regency.getByProvinceId(req.params.provinceId);
    return successResponse(res, 'Daftar kabupaten berhasil diambil', regencies);
  } catch (err) {
    return errorResponse(res, 'Gagal mengambil daftar kabupaten', { detail: err.message });
  }
};

const createRegency = async (req, res) => {
  const { regency_id, province_id, name } = req.body;
  if (!regency_id || !province_id || !name) {
    return errorResponse(res, 'regency_id, province_id, dan name wajib diisi', {}, 400);
  }
  try {
    const regency = await Regency.create(regency_id, province_id, name);
    return successResponse(res, 'Kabupaten berhasil ditambah', regency, 201);
  } catch (err) {
    return errorResponse(res, 'Gagal menambah kabupaten', { detail: err.message });
  }
};

const updateRegency = async (req, res) => {
  const { name } = req.body;
  if (!name) {
    return errorResponse(res, 'Nama kabupaten wajib diisi', {}, 400);
  }
  try {
    const updated = await Regency.update(req.params.id, name);
    if (!updated) {
      return errorResponse(res, 'Kabupaten tidak ditemukan', {}, 404);
    }
    return successResponse(res, 'Kabupaten berhasil diperbarui', { regency_id: req.params.id, name });
  } catch (err) {
    return errorResponse(res, 'Gagal memperbarui kabupaten', { detail: err.message });
  }
};

const deleteRegency = async (req, res) => {
  try {
    const deleted = await Regency.delete(req.params.id);
    if (!deleted) {
      return errorResponse(res, 'Kabupaten tidak ditemukan', {}, 404);
    }
    return successResponse(res, 'Kabupaten berhasil dihapus', {});
  } catch (err) {
    return errorResponse(res, 'Gagal menghapus kabupaten', { detail: err.message });
  }
};

module.exports = {
  getRegencies,
  getRegencyById,
  getRegenciesByProvinceId,
  createRegency,
  updateRegency,
  deleteRegency,
};
