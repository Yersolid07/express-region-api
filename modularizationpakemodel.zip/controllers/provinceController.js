const Province = require('../models/provinceModel');
const { successResponse, errorResponse } = require('../utils/response');

const getProvinces = async (req, res) => {
  try {
    const provinces = await Province.getAll();
    return successResponse(res, 'Daftar provinsi berhasil diambil', {
      items: provinces,
      total: provinces.length,
      page: parseInt(req.query.page) || 1,
      limit: parseInt(req.query.limit) || 10,
      totalPages: Math.ceil(provinces.length / (parseInt(req.query.limit) || 10)),
    });
  } catch (err) {
    return errorResponse(res, 'Gagal mengambil daftar provinsi', { detail: err.message });
  }
};

const getProvinceById = async (req, res) => {
  try {
    const province = await Province.getById(req.params.id);
    if (!province) {
      return errorResponse(res, 'Provinsi tidak ditemukan', {}, 404);
    }
    return successResponse(res, 'Provinsi berhasil diambil', province);
  } catch (err) {
    return errorResponse(res, 'Gagal mengambil provinsi', { detail: err.message });
  }
};

const createProvince = async (req, res) => {
  const { province_id, name } = req.body;
  if (!province_id || !name) {
    return errorResponse(res, 'province_id dan name wajib diisi', {}, 400);
  }
  try {
    const province = await Province.create(province_id, name);
    return successResponse(res, 'Provinsi berhasil ditambah', province, 201);
  } catch (err) {
    return errorResponse(res, 'Gagal menambah provinsi', { detail: err.message });
  }
};

const updateProvince = async (req, res) => {
  const { name } = req.body;
  if (!name) {
    return errorResponse(res, 'Nama provinsi wajib diisi', {}, 400);
  }
  try {
    const updated = await Province.update(req.params.id, name);
    if (!updated) {
      return errorResponse(res, 'Provinsi tidak ditemukan', {}, 404);
    }
    return successResponse(res, 'Provinsi berhasil diperbarui', { province_id: req.params.id, name });
  } catch (err) {
    return errorResponse(res, 'Gagal memperbarui provinsi', { detail: err.message });
  }
};

const deleteProvince = async (req, res) => {
  try {
    const deleted = await Province.delete(req.params.id);
    if (!deleted) {
      return errorResponse(res, 'Provinsi tidak ditemukan', {}, 404);
    }
    return successResponse(res, 'Provinsi berhasil dihapus', {});
  } catch (err) {
    return errorResponse(res, 'Gagal menghapus provinsi', { detail: err.message });
  }
};

module.exports = {
  getProvinces,
  getProvinceById,
  createProvince,
  updateProvince,
  deleteProvince,
};
