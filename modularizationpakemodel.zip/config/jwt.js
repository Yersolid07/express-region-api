require('dotenv').config();

module.exports = {
  secretKey: 'your-secret-key-here', // Ganti dengan secret key yang lebih aman untuk production
  options: {
    expiresIn: '24h', // Token akan expired dalam 24 jam
  },
};
