const mysql = require('mysql2/promise');
require('dotenv').config();

const dbConfig = {
  host: process.env.DB_HOST || '127.0.0.1',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'wilayah-db',
};

let db;

const initializeDatabase = async () => {
  try {
    db = await mysql.createConnection(dbConfig);
    console.log('Berhasil terhubung ke MySQL');
    return db;
  } catch (err) {
    console.error('Gagal terhubung ke MySQL:', err);
    process.exit(1);
  }
};

module.exports = {
  initializeDatabase,
  getConnection: () => db,
};
