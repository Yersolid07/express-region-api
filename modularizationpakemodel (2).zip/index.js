const express = require('express');
const cors = require('cors');
const { initializeDatabase } = require('./config/database');
const { errorResponse } = require('./utils/response');

// Import routes
const authRoutes = require('./routes/authRoutes');
const provinceRoutes = require('./routes/provinceRoutes');
const regencyRoutes = require('./routes/regencyRoutes');
const districtRoutes = require('./routes/districtRoutes');
const villageRoutes = require('./routes/villageRoutes');

const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Root route
app.get('/', (req, res) => {
  res.json({
    message: 'Selamat datang di API Wilayah Indonesia',
    version: '1.0.0',
    endpoints: {
      auth: {
        login: 'POST /api/v1/auth/login',
        logout: 'POST /api/v1/auth/logout',
      },
      provinces: {
        list: 'GET /api/v1/provinces',
        detail: 'GET /api/v1/provinces/:id',
        create: 'POST /api/v1/provinces',
        update: 'PATCH /api/v1/provinces/:id',
        delete: 'DELETE /api/v1/provinces/:id',
      },
      regencies: {
        list: 'GET /api/v1/regencies',
        detail: 'GET /api/v1/regencies/:id',
        create: 'POST /api/v1/regencies',
        update: 'PATCH /api/v1/regencies/:id',
        delete: 'DELETE /api/v1/regencies/:id',
        byProvince: 'GET /api/v1/regencies/province/:provinceId',
      },
      districts: {
        list: 'GET /api/v1/districts',
        detail: 'GET /api/v1/districts/:id',
        create: 'POST /api/v1/districts',
        update: 'PATCH /api/v1/districts/:id',
        delete: 'DELETE /api/v1/districts/:id',
        byRegency: 'GET /api/v1/districts/regency/:regencyId',
      },
      villages: {
        list: 'GET /api/v1/villages',
        detail: 'GET /api/v1/villages/:id',
        create: 'POST /api/v1/villages',
        update: 'PATCH /api/v1/villages/:id',
        delete: 'DELETE /api/v1/villages/:id',
        byDistrict: 'GET /api/v1/villages/district/:districtId',
      },
    },
  });
});

// API Routes
app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/provinces', provinceRoutes);
app.use('/api/v1/regencies', regencyRoutes);
app.use('/api/v1/districts', districtRoutes);
app.use('/api/v1/villages', villageRoutes);

// Error handling untuk JWT
app.use((err, req, res, next) => {
  if (err.name === 'UnauthorizedError') {
    return errorResponse(res, err.code === 'credentials_required' ? 'Token tidak ada' : 'Token tidak valid atau kadaluarsa', {}, 401);
  }
  next(err);
});

// Error handler untuk error lainnya
app.use((err, req, res, next) => {
  console.error(err.stack);
  return errorResponse(res, 'Terjadi kesalahan internal server', { detail: process.env.NODE_ENV === 'development' ? err.message : 'Internal server error' }, 500);
});

// 404 handler
app.use((req, res) => {
  errorResponse(res, 'Route tidak ditemukan', {}, 404);
});

// Initialize database and start server
const startServer = async () => {
  try {
    await initializeDatabase();
    app.listen(port, () => {
      console.log(`Server berjalan di http://localhost:${port}`);
    });
  } catch (err) {
    console.error('Gagal menjalankan server:', err);
    process.exit(1);
  }
};

startServer();
